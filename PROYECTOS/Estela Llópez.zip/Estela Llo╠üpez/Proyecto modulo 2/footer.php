 <!-- **Inicio footer** -->
    <footer>
        <!-- Contenedor copyright y autor -->
        <div class="autoria">
            <p>&copy 2019 - Estela López Martín</p>
        </div>
        <!-- Contenedor redes sociales -->
        <div class="social">
            <a href="contacto.php" class="contactanos">Contáctanos</a>
            <a href="#" class="facebook">f</a>
            <a href="#" class="twitter">t</a>
            <a href="#" class="linkedin">in</a>
        </div>
    </footer>