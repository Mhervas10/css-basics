<!DOCTYPE html>
<html lang="es">
<head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <meta name="description" content="Esta es la página web de contacto de Estela López Martín">
        <meta name="keywords" content="Estela López Martín, Curriculum Vitae,  Diseño, Diseñador, Informática, Programación, Front End Developer ">
        <meta name="author" content="Estela López Martín">
        <meta name="robots" content="index, follow">
        <!-- Link Reset Meyer -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.css">
        <!-- Link Google Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Amatic+SC|Comfortaa|Lobster+Two|Raleway&display=swap" rel="stylesheet">
        <!-- Favicon -->
        <link rel="icon" href="./img/favicon.ico" type="image/x-icon">
        <!-- Link a hoja de estilos de Animate.css -->
        <link rel="stylesheet" href="css/animation.css">
        <!-- Link a hoja de estilos personal -->
        <link rel="stylesheet" href="css/style.css">
    
        <title>Trabajos - The Happy Web Agency</title>
</head>
<body class="trabajos">

   <!-- Contenedor principal con el menú y el main -->
   <div id="principal">
        
        <!-- **Menú de navegación** -->
        <nav>
            <!-- Div contenedor de la imagen del menú -->
            <label for="patatas">
                <!-- Imagen con efecto en JavaScript -->
                <div class="imagen-patatas" onclick="myFunction(this)"></div>
            </label>
            <input type="checkbox" id="patatas">
            <!-- Lista de menú -->
            <ul class="menu">
                <li><a href="Index.php">inicio</a></li>
                <li><a href="nosotros.php">nosotros</a></li>
                <li><a href="#">trabajos</a></li>
                <li><a href="contacto.php">contacto</a></li>
            </ul>
        </nav>

        <!-- **Inicio sección principal** -->
        <main>
            <!-- Título -->
            <h1>Algunos de nuestros trabajos</h1>
            <!-- Contenedor general de los artículos -->
            <section class="portfolio">

                <!-- Contenedor artículo interacción con JavaScript -->
                <article id="myBtn">
                    <!-- Contenedor del título del trabajo -->
                    <div class="texto">
                        <h2 class="mayus">delhi</h2>
                    </div>
                    <!-- Contenedor con la imagen de cada trabajo -->
                    <div class="bg-img work1 opacidad">
                    </div>

                    <!-- Contenedor con descripción de los trabajos -->
                    <div class="escondido estilos">
                        <p> Hechas, pues, estas prevenciones, no quiso aguardar más tiempo a poner en efeto su pensamiento, apretándole a ello la falta que él pensaba que hacía en el mundo su tardanza, según eran los agravios que pensaba deshacer, tuertos que enderezar, sinrazones que enmendar, y abusos que mejorar, y deudas que satisfacer. Y así, sin dar parte a persona alguna de su intención, y sin que nadie le viese, una mañana, antes del día, que era uno de los calurosos del mes de julio, se armó de todas sus armas, subió sobre Rocinante, puesta su mal compuesta celada, embrazó su adarga, tomó su lanza, y, por la puerta falsa de un corral, salió al campo con grandísimo contento y alborozo de ver con cuánta facilidad había dado principio a su buen deseo. </p>
                        <!-- Colores -->
                        <h3>Paleta de colores</h3>
                        <ul class="colores mayus">
                            <li><div></div><p>#e98c01</p></li>
                            <li><div></div><p>#9d8d7f</p></li>
                            <li><div></div><p>#dfcda8</p></li>
                            <li><div></div><p>#3b5258</p></li>
                        </ul>
                        <!-- Tipografías -->
                        <h3>Tipografías</h3>
                        <ul class="tipografias">
                            <li><a href="https://fonts.google.com/specimen/Roboto" target="_blank"> <img src="./img/texto1.png" alt="Imagen tipografía Roboto" title="Tipografía Roboto"></a></li>
                            <li><a href="https://fonts.google.com/specimen/Literata?selection.family=Amatic+SC:400,700|Comfortaa|Raleway&query=litera" target="_blank"><img src="./img/texto2.png" alt="Imagen tipografía Literata" title="Tipografía Literata"></a></li>
                        </ul>
                        <p>Mas, apenas se vio en el campo, cuando le asaltó un pensamiento terrible, y tal, que por poco le hiciera dejar la comenzada empresa; y fue que le vino a la memoria que no era armado caballero, y que, conforme a ley de caballería, ni podía ni debía tomar armas con ningún caballero; y, puesto que lo fuera, había de llevar armas blancas, como novel caballero, sin empresa en el escudo, hasta que por su esfuerzo la ganase.</p>
                    </div>
                </article>

                <!-- Inicio de Modal Box -->
                <div id="myModal" class="modal">
                    <div class="modal-content">
                        <span class="close">&times;</span>
                        <div class="estilos">
                        <p> Hechas, pues, estas prevenciones, no quiso aguardar más tiempo a poner en efeto su pensamiento, apretándole a ello la falta que él pensaba que hacía en el mundo su tardanza, según eran los agravios que pensaba deshacer, tuertos que enderezar, sinrazones que enmendar, y abusos que mejorar, y deudas que satisfacer. Y así, sin dar parte a persona alguna de su intención, y sin que nadie le viese, una mañana, antes del día, que era uno de los calurosos del mes de julio, se armó de todas sus armas, subió sobre Rocinante, puesta su mal compuesta celada, embrazó su adarga, tomó su lanza, y, por la puerta falsa de un corral, salió al campo con grandísimo contento y alborozo de ver con cuánta facilidad había dado principio a su buen deseo. </p>
                        <h3>Paleta de colores</h3>
                        <ul class="colores mayus">
                            <li><div></div><p>#e98c01</p></li>
                            <li><div></div><p>#9d8d7f</p></li>
                            <li><div></div><p>#dfcda8</p></li>
                            <li><div></div><p>#3b5258</p></li>
                        </ul>
                        <h3>Tipografías</h3>
                        <ul class="tipografias">
                            <li><a href="https://fonts.google.com/specimen/Roboto" target="_blank"> <img src="./img/texto1.png" alt="Imagen tipografía Roboto" title="Tipografía Roboto"></a></li>
                            <li><a href="https://fonts.google.com/specimen/Literata?selection.family=Amatic+SC:400,700|Comfortaa|Raleway&query=litera" target="_blank"><img src="./img/texto2.png" alt="Imagen tipografía Literata" title="Tipografía Literata"></a></li>
                        </ul>
                        <p>Mas, apenas se vio en el campo, cuando le asaltó un pensamiento terrible, y tal, que por poco le hiciera dejar la comenzada empresa; y fue que le vino a la memoria que no era armado caballero, y que, conforme a ley de caballería, ni podía ni debía tomar armas con ningún caballero; y, puesto que lo fuera, había de llevar armas blancas, como novel caballero, sin empresa en el escudo, hasta que por su esfuerzo la ganase.</p>
                        <img src="./img/indian.jpg" alt="Imagen trabajo Restaurante Indio" title="Delhi" width="100%">
                    </div>
                    </div>
                </div>

                <article id="myBtnDos">
                    <div class="texto">
                        <h2 class="mayus">tokyo </h2>
                    </div>
                    <div class="bg-img work2 opacidad">
                    </div>
                    <div class="escondido estilos">
                        <p> Estos pensamientos le hicieron titubear en su propósito; mas, pudiendo más su locura que otra razón alguna, propuso de hacerse armar caballero del primero que topase, a imitación de otros muchos que así lo hicieron, según él había leído en los libros que tal le tenían. En lo de las armas blancas, pensaba limpiarlas de manera, en teniendo lugar, que lo fuesen más que un armiño; y con esto se quietó y prosiguió su camino, sin llevar otro que aquél que su caballo quería, creyendo que en aquello consistía la fuerza de las aventuras.</p>
                        <h3>Paleta de colores</h3>
                        <ul class="colores muestra mayus">
                            <li><div></div><p>#484852</p></li>
                            <li><div></div><p>#2d382a</p></li>
                            <li><div></div><p>#fdc578</p></li>
                            <li><div></div><p>#ff7625</p></li>
                        </ul>
                        
                        <h3>Tipografías</h3>
                        <ul class="tipografias">
                            <li><a href="https://fonts.google.com/specimen/Bahianita" target="_blank"> <img src="./img/texto3.png" alt="Imagen tipografía Bahianita" title="Tipografía Bahianita"></a></li>
                            <li><a href="https://fonts.google.com/specimen/Open+Sans" target="_blank"><img src="./img/texto4.png" alt="Imagen tipografía Open Sans" title="Tipografía Open Sans"></a></li>
                        </ul>
                        <p>Yendo, pues, caminando nuestro flamante aventurero, iba hablando consigo mesmo y diciendo: «¿Quién duda sino que en los venideros tiempos, cuando salga a luz la verdadera historia de mis famosos hechos, que el sabio que los escribiere no ponga, cuando llegue a contar esta mi primera salida tan de mañana, desta manera?</p>
                    </div>
                </article>

                <div id="myModalDos" class="modal">
                    <div class="modal-content">
                        <span class="close">&times;</span>
                        <div class="estilos">
                        <p> Estos pensamientos le hicieron titubear en su propósito; mas, pudiendo más su locura que otra razón alguna, propuso de hacerse armar caballero del primero que topase, a imitación de otros muchos que así lo hicieron, según él había leído en los libros que tal le tenían. En lo de las armas blancas, pensaba limpiarlas de manera, en teniendo lugar, que lo fuesen más que un armiño; y con esto se quietó y prosiguió su camino, sin llevar otro que aquél que su caballo quería, creyendo que en aquello consistía la fuerza de las aventuras.</p>
                        <h3>Paleta de colores</h3>
                        <ul class="colores muestra mayus">
                            <li><div></div><p>#484852</p></li>
                            <li><div></div><p>#2d382a</p></li>
                            <li><div></div><p>#fdc578</p></li>
                            <li><div></div><p>#ff7625</p></li>
                        </ul>
                        
                        <h3>Tipografías</h3>
                        <ul class="tipografias">
                            <li><a href="https://fonts.google.com/specimen/Bahianita" target="_blank"> <img src="./img/texto3.png" alt="Imagen tipografía Bahianita" title="Tipografía Bahianita"></a></li>
                            <li><a href="https://fonts.google.com/specimen/Open+Sans" target="_blank"><img src="./img/texto4.png" alt="Imagen tipografía Open Sans" title="Tipografía Open Sans"></a></li>
                        </ul>
                        <p>Yendo, pues, caminando nuestro flamante aventurero, iba hablando consigo mesmo y diciendo: «¿Quién duda sino que en los venideros tiempos, cuando salga a luz la verdadera historia de mis famosos hechos, que el sabio que los escribiere no ponga, cuando llegue a contar esta mi primera salida tan de mañana, desta manera?</p>
                        <img src="./img/sushi.jpg" alt="Imagen Web Restaurante Japones" title="Tokyo" width="100%">
                    </div>
                    </div>
                </div>

                <article id="myBtnTres">
                    <div class="texto">
                        <h2 class="mayus">abstract </h2>
                    </div>
                    <div class="bg-img work3 opacidad">
                    </div>
                    <div class="escondido estilos">
                        <p> 'Apenas había el rubicundo Apolo tendido por la faz de la ancha y espaciosa tierra las doradas hebras de sus hermosos cabellos, y apenas los pequeños y pintados pajarillos con sus harpadas lenguas habían saludado con dulce y meliflua armonía la venida de la rosada aurora, que, dejando la blanda cama del celoso marido, por las puertas y balcones del manchego horizonte a los mortales se mostraba, cuando el famoso caballero don Quijote de la Mancha, dejando las ociosas plumas, subió sobre su famoso caballo Rocinante; y comenzó a caminar por el antiguo y conocido campo de Montiel».</p>
                        <h3>Paleta de colores</h3>
                        <ul class="colores paleta mayus">
                            <li><div></div><p>#668fb1</p></li>
                            <li><div></div><p>#da4e69</p></li>
                            <li><div></div><p>#23085f</p></li>
                            <li><div></div><p>#bbefc1</p></li>
                        </ul>
                        
                        <h3>Tipografías</h3>
                        <ul class="tipografias">
                            <li><a href="https://fonts.google.com/specimen/Barriecito" target="_blank"><img src="./img/texto5.png" alt="Imagen tipografía Barriecito" title="Tipografía Barriecito"></a></li>
                            <li><a href="https://fonts.google.com/specimen/Raleway" target="_blank"><img src="./img/texto6.png" alt="Imagen tipografía Raleway" title="Tipografía Raleway"></a></li>
                        </ul>
                        <p>Y era la verdad que por él caminaba. Y añadió diciendo: «Dichosa edad, y siglo dichoso aquél adonde saldrán a luz las famosas hazañas mías, dignas de entallarse en bronces, esculpirse en mármoles y pintarse en tablas, para memoria en lo futuro. ¡Oh tú, sabio encantador, quienquiera que seas, a quien ha de tocar el ser coronista desta peregrina historia! Ruégote que no te olvides de mi buen Rocinante, compañero eterno mío en todos mis caminos y carreras».</p>
                    </div>
                </article>

                <div id="myModalTres" class="modal">
                    <div class="modal-content">
                        <span class="close">&times;</span>
                        <div class="estilos">
                        <p> 'Apenas había el rubicundo Apolo tendido por la faz de la ancha y espaciosa tierra las doradas hebras de sus hermosos cabellos, y apenas los pequeños y pintados pajarillos con sus harpadas lenguas habían saludado con dulce y meliflua armonía la venida de la rosada aurora, que, dejando la blanda cama del celoso marido, por las puertas y balcones del manchego horizonte a los mortales se mostraba, cuando el famoso caballero don Quijote de la Mancha, dejando las ociosas plumas, subió sobre su famoso caballo Rocinante; y comenzó a caminar por el antiguo y conocido campo de Montiel».</p>
                        <h3>Paleta de colores</h3>
                        <ul class="colores paleta mayus">
                            <li><div></div><p>#668fb1</p></li>
                            <li><div></div><p>#da4e69</p></li>
                            <li><div></div><p>#23085f</p></li>
                            <li><div></div><p>#bbefc1</p></li>
                        </ul>
                        
                        <h3>Tipografías</h3>
                        <ul class="tipografias">
                            <li><a href="https://fonts.google.com/specimen/Barriecito" target="_blank"><img src="./img/texto5.png" alt="Imagen tipografía Barriecito" title="Tipografía Barriecito"></a></li>
                            <li><a href="https://fonts.google.com/specimen/Raleway" target="_blank"><img src="./img/texto6.png" alt="Imagen tipografía Raleway" title="Tipografía Raleway"></a></li>
                        </ul>
                        <p>Y era la verdad que por él caminaba. Y añadió diciendo: «Dichosa edad, y siglo dichoso aquél adonde saldrán a luz las famosas hazañas mías, dignas de entallarse en bronces, esculpirse en mármoles y pintarse en tablas, para memoria en lo futuro. ¡Oh tú, sabio encantador, quienquiera que seas, a quien ha de tocar el ser coronista desta peregrina historia! Ruégote que no te olvides de mi buen Rocinante, compañero eterno mío en todos mis caminos y carreras».</p>
                        <img src="./img/data.jpg" alt="Imagen trabajo Abstracto"  title="Abstract" width="100%">
                    </div>
                    </div>
                </div>

            </section>
           
        </main>

    </div>
    <!-- Footer -->
    <?php include 'footer.php'; ?>

  <!-- Javascript personal -->
  <script type="text/javascript" src="./js/script.js"></script>
  <!-- JavaScript FontAwesome -->
  <script src="https://kit.fontawesome.com/a0d3b07a7a.js"></script>
</body>
</html>