document.body.addEventListener('mousemove',function(e){
    var top = e.pageY;
    var left = e.pageX;
    var torch = document.getElementById('luz');
    torch.style.clip = "rect("+(top-200)+"px,"+left+"px,"+top+"px,"+(left-200)+"px)";
  });

alert("Mueve el ratón para ver qué pasa");
