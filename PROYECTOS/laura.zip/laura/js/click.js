function hizoClick() {
    alert("Tu mensaje se ha enviado correctamente");
}