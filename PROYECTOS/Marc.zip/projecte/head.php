<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css"/>
    <link rel="icon" href="favicon-16x16.png">
    <link href="https://fonts.googleapis.com/css?family=Black+Ops+One|Chakra+Petch&display=swap" rel="stylesheet">
    <meta name="the jungle" content="web for practicing purposes, it has a jungle inspired style and it's filled with lorem">
   <meta name="jungle, snake, amazonas, jumanji" content="lorem">
   <meta name="robots" content="">
    <title>La Jungla</title>
    