<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css"/>
    <link href="https://fonts.googleapis.com/css?family=Black+Ops+One|Chakra+Petch&display=swap" rel="stylesheet">
    <title>Document</title>
    <style>
/* colors */
/* #DDC19C,#182C06,#799217 */
    .foto{
    background-image: url(TheJungle.jpg);
    background-position: center;
    background-repeat: no-repeat; 
    background-size: cover;
    display: flex;
    flex-direction: column;
    flex-wrap:nowrap;
    height:100vh;
    align-items:center;
    justify-content: space-between;
    }
    .divmain{background-image: url(giphy.gif);
    background-position: center;
    background-repeat: no-repeat; 
    background-size: cover;
    }
    svg{filter:drop-shadow(0 0 5px black);
    width:100px;}
    .divmainsvg{
    background-color:transparent;
    outline: 1px transparent solid;
    }
    .divsvg{
    background-color:transparent;
    outline: 1px transparent solid;}
    .fletxessvg:hover{transform: scale(1.5);
      filter:drop-shadow(0 0 5px rgb(63,39,10));
      }
    .serpsvg:hover{visibility: hidden;
    }
    .serpiente{display:grid;
      grid-template-areas: 
        "serpiente";
    }
    .serpiente svg{grid-area: serpiente;
    }
    .serp2svg:hover{
      transform: scale(1.5);
      filter:drop-shadow(0 0 5px rgb(63,39,10));
    }
    .llibreria{display:none;}
    .contenidor{
    background-image: url(different_camouflage_pattern_design_vector_set.svg);
    background-position: center;
    background-repeat: no-repeat; 
    background-size:cover;
    }
    .layer {
    background-color: rgba(0, 0, 0, 0.6);
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
}
    h1{color: #DDC19C;
    text-shadow: 0 0 5px black;
    font-size: 5rem;
    font-family: 'Black Ops One', cursive;
    margin-top: 30vh;}
    h2{color:#DDC19C;
    text-shadow: 0 0 5px black;
    font-family: 'Black Ops One', cursive;
    font-size: 2rem;
    margin-bottom: 1rem;}
    P{font-family: 'Chakra Petch', sans-serif;
    color:#DDC19C;
    text-shadow: 0 0 5px black;
    }
    div{
    background-color: #182C06;
    outline: 1px #799217 solid;
    text-align: center;
    }
    .divmenu, .divmain, .divaside1, .divaside2, .divbottom{background-color: transparent;
    padding:10px;
    }
    .divfooter{
    padding: 10px;
    display: flex;
    flex-direction: column;
    
    justify-content: center;
    
    }
    .divfooter p{
    color:#DDC19C;
    text-shadow: 0 0 5px black;
    font-family: 'Black Ops One', cursive;
    }
    
    .divmenu{grid-area: menu;
    }
    .divmain{grid-area: main;
    }
    .divaside1{grid-area: right;
    }
    .divaside2{grid-area: left;
    }
    .divbottom{grid-area: prefooter;
    }

    .layer{
        display: grid;
        grid-template-areas: 
        "menu"
        "main"
        "right"
        "left"
        "prefooter ";
        grid-template-rows: 1fr 2fr 1fr 1fr 1fr;
        grid-template-columns: auto;
        }
    /* .divmain{height: 33vh;
    width:100%;} */

     @media (min-width:720px){   
    .layer{
    display: grid;
    grid-template-areas: 
        "menu menu menu menu"
        "left left main main"
        "right right right right"
        "prefooter prefooter prefooter prefooter";
        grid-template-rows: 1fr 2fr 1fr 1fr;
        grid-template-columns: 1fr 2fr 2fr 1fr;
        }
   
     }
     @media (min-width:1200px){ 
    .layer{
        display: grid;
        grid-template-areas: 
        "menu menu menu menu"
        "left main main right"
        "prefooter prefooter prefooter prefooter";
        grid-template-rows: 1fr 2fr 1fr;
        grid-template-columns: 2fr 1fr 1fr 2fr;
        }
        
     }

/* ESTRUCTURA */

nav ul{
  display: flex;
  flex-direction: column;
  box-sizing: border-box;
}
nav li a{
  padding:0.5rem 1.5rem;
  display:block;
}
/* DECORATION */
nav ul{
  list-style: none;
  background: #182C06;
}
nav li a{
  text-decoration: none;
  color: #DDC19C;
  text-shadow: 0 0 5px black;
  font-family: 'Black Ops One', cursive;
          
}
nav li:hover{
  background-image: url(jungle.jpg);
  background-position: center;
  background-repeat: no-repeat; 
  background-size: cover;
}
nav li a:hover{
color:rgb(14, 26, 3);
text-shadow: 0 0 5px white;
}
/* HAMBURGUER */

/* Hide Hamburger */
#page-nav label, #hamburger{
  display: none;
}
/* Show Hamburger */
#page-nav label{
  display: inline-block;
  color: #DDC19C;
  background: #182c06;
  font-style: normal;
  font-size: 1.2em;
  padding: 10px;
  width: 100%;
  border-bottom:#799217 2px solid;
  border-top:#799217 2px solid;
}
/* Break down menu items into vertical */
#page-nav ul li{
  display: block;
}
/* Toggle show/hide menu on checkbox click */
#page-nav ul{
  display: none;
}
#page-nav input:checked ~ ul{
  display: block;
} 
nav li{
  border-top:#799217 2px solid;
  }
nav ul{
  border-bottom:#799217 2px solid;
  }
/* MEDIA QUERIES */
@media (min-width: 575.98px){
#page-nav ul {
  display: flex;
}
#page-nav input:checked ~ ul{
  display: flex;
}
nav ul{
  flex-direction: row;
  }
.nav4 li{
  flex:1; text-align: center;
}
nav li:nth-child(2), nav li:nth-child(3), nav li:nth-child(1){
  border-left:#799217 2px solid;        
}
nav li:nth-child(3), nav li:nth-child(4){
  border-right:#799217 2px solid;
}
/* Hide Hamburger */
#page-nav label, #hamburger {
  display: none;
}
}
    </style>
</head>
<body>
    <header>
    <div class="foto"><h1>WELCOME TO THE JUNGLE</h1>
        <div class="divmainsvg">    
        <div class="divsvg serpiente">
            <svg class="serp2svg"><use xlink:href="#serp2"></use></svg>
            <svg class="serpsvg"><use xlink:href="#serp"></use></svg>
            
        </div>
        <div class="divsvg">
          <a href="#page-nav"><svg class="fletxessvg"><use xlink:href="#fletxes"></use></svg></a>
        </div>
        </div>
    </div>
         
    </header>
    <main class="contenidor">
        <nav class="nav4" id="page-nav">
            <label for="hamburger">&#9776;</label>
            <input type="checkbox" id="hamburger"/>
        <ul>
            <li><a href="#">1-Inici</a></li>
            <li><a href="#">2-Qui som</a></li>
            <li><a href="#">3-Els nostres treballs</a></li>
            <li><a href="#">4-Contacte i localització</a></li>
        </ul>
        </nav>
        <div class="layer">
        <div class="divmenu"><h2>Lorem</h2><p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio temporibus hic placeat eligendi dolores consequatur eius ea blanditiis, assumenda sapiente soluta repellat omnis molestiae ex debitis dolore autem fugiat asperiores!
        Esse rem nostrum autem quo. Velit quibusdam excepturi inventore eaque. Totam saepe, est quam in numquam unde a quo, libero facere qui odit non reprehenderit repellendus quae dolor sit eius!
        Rem beatae ipsum tenetur odit, quia fuga natus possimus, delectus, assumenda magnam minus asperiores provident. Sapiente ad rerum corrupti, a inventore nemo facere adipisci soluta animi omnis laboriosam? Facilis, enim.</p></div>
        <div class="divmain"></div>
        <div class="divaside1"><h2>Lorem</h2><p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio temporibus hic placeat eligendi dolores consequatur eius ea blanditiis, assumenda sapiente soluta repellat omnis molestiae ex debitis dolore autem fugiat asperiores!
        Esse rem nostrum autem quo. Velit quibusdam excepturi inventore eaque. Totam saepe, est quam in numquam unde a quo, libero facere qui odit non reprehenderit repellendus quae dolor sit eius!
        Rem beatae ipsum tenetur odit, quia fuga natus possimus, delectus, assumenda magnam minus asperiores provident. Sapiente ad rerum corrupti, a inventore nemo facere adipisci soluta animi omnis laboriosam? Facilis, enim.</p></div>
        <div class="divaside2"><h2>Lorem</h2><p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio temporibus hic placeat eligendi dolores consequatur eius ea blanditiis, assumenda sapiente soluta repellat omnis molestiae ex debitis dolore autem fugiat asperiores!
        Esse rem nostrum autem quo. Velit quibusdam excepturi inventore eaque. Totam saepe, est quam in numquam unde a quo, libero facere qui odit non reprehenderit repellendus quae dolor sit eius!
        Rem beatae ipsum tenetur odit, quia fuga natus possimus, delectus, assumenda magnam minus asperiores provident. Sapiente ad rerum corrupti, a inventore nemo facere adipisci soluta animi omnis laboriosam? Facilis, enim.</p></div>
        <div class="divbottom"><h2>Lorem</h2><p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio temporibus hic placeat eligendi dolores consequatur eius ea blanditiis, assumenda sapiente soluta repellat omnis molestiae ex debitis dolore autem fugiat asperiores!
        Esse rem nostrum autem quo. Velit quibusdam excepturi inventore eaque. Totam saepe, est quam in numquam unde a quo, libero facere qui odit non reprehenderit repellendus quae dolor sit eius!
        Rem beatae ipsum tenetur odit, quia fuga natus possimus, delectus, assumenda magnam minus asperiores provident. Sapiente ad rerum corrupti, a inventore nemo facere adipisci soluta animi omnis laboriosam? Facilis, enim.</p></div>
    </div>
    </main>
    <footer>
       <div class="divfooter">
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum, vitae repellendus.</p>
        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit.</p>
        </div> 
    </footer>
    
</body>

<svg class="llibreria" viewBox="0 0 250 250" width="250pt" height="250pt">
        <symbol id="serp" viewBox="0 0 250 250">
            <path d=" M 44.539 5.668 C 38.639 7.768 34.839 10.568 33.039 14.068 L 31.539 16.968 L 36.339 17.568 C 43.139 18.468 49.639 20.768 52.639 23.368 C 54.039 24.568 57.239 28.268 59.739 31.568 C 64.839 38.268 69.539 42.768 77.339 48.868 L 82.639 52.968 L 78.839 53.768 C 72.039 55.168 56.439 54.568 50.439 52.768 C 37.639 48.868 31.139 39.868 31.039 25.868 L 31.039 18.068 L 27.139 18.068 C 17.539 18.068 9.439 23.368 5.439 32.268 C 3.339 36.868 3.039 39.068 3.039 49.068 C 3.139 71.968 7.739 78.768 48.239 117.068 C 54.339 122.868 60.139 129.168 61.039 131.068 C 62.039 132.968 64.539 142.468 66.539 152.068 C 73.639 185.268 78.839 201.568 84.939 209.468 C 86.239 211.168 89.339 216.768 91.939 221.868 C 94.439 226.968 98.239 232.868 100.139 235.068 C 104.539 239.868 114.139 244.668 121.239 245.568 C 127.139 246.368 136.339 244.768 141.539 242.068 C 147.139 239.168 153.739 231.368 158.939 221.068 C 161.639 215.868 164.939 210.168 166.239 208.468 C 171.439 201.568 176.239 186.268 183.039 154.568 C 188.539 129.068 189.039 128.168 207.939 111.068 C 231.239 90.068 239.639 80.068 244.639 67.168 C 246.539 62.468 246.939 59.468 246.939 48.568 C 247.039 35.768 246.939 35.468 243.939 30.068 C 239.939 22.968 234.039 19.068 225.839 18.368 C 220.539 17.868 219.939 17.568 218.539 14.668 C 215.439 8.168 203.739 3.468 193.139 4.368 C 189.039 4.668 185.039 5.868 181.039 7.968 C 169.539 13.968 134.539 18.068 112.339 16.168 C 90.839 14.268 76.939 11.568 70.039 7.968 C 62.539 4.068 51.739 3.068 44.539 5.668 Z  M 220.139 21.568 C 221.739 30.068 217.239 42.768 210.939 47.568 C 203.039 53.568 190.839 55.968 175.939 54.568 L 168.039 53.868 L 170.939 51.668 C 179.339 45.568 186.839 38.468 191.539 32.068 C 199.039 21.868 205.039 18.268 214.739 18.168 C 219.339 18.068 219.439 18.168 220.139 21.568 Z  M 108.239 63.368 C 103.039 66.768 103.039 66.568 108.239 69.868 C 114.339 73.768 117.539 77.068 115.339 77.068 C 113.239 77.068 96.539 66.868 97.139 65.968 C 97.739 64.968 106.239 62.168 108.539 62.168 C 109.639 62.168 109.639 62.468 108.239 63.368 Z  M 149.539 63.668 L 154.839 65.268 L 150.439 68.168 C 144.939 71.968 136.439 76.368 135.939 75.768 C 135.639 75.568 137.939 73.468 141.039 71.068 C 144.039 68.768 146.539 66.568 146.539 66.368 C 146.539 66.068 145.539 65.068 144.339 63.968 C 141.539 61.668 142.639 61.568 149.539 63.668 Z  M 60.339 86.768 C 62.039 87.768 66.839 91.368 70.839 94.768 L 78.239 100.968 L 77.739 113.268 C 77.439 122.368 77.739 127.368 78.939 132.468 C 80.839 140.468 87.039 152.868 92.039 158.568 L 95.539 162.568 L 92.939 156.668 C 87.139 143.068 86.239 130.668 90.339 117.568 C 91.839 112.468 92.439 111.568 94.239 111.868 C 95.739 112.068 98.639 110.068 103.639 105.568 C 112.739 97.468 117.739 94.968 124.939 94.968 C 132.239 94.968 137.439 97.768 144.939 105.668 C 149.539 110.568 151.639 112.068 153.739 112.068 C 156.139 112.068 156.639 112.668 158.039 117.268 C 162.039 130.368 160.839 146.368 154.939 158.468 L 152.439 163.568 L 156.539 159.068 C 161.139 154.068 167.739 141.068 169.439 133.768 C 171.239 126.068 171.839 114.068 170.639 108.068 L 169.639 102.568 L 175.039 97.368 C 187.239 85.768 195.939 82.368 201.839 87.068 C 207.439 91.468 207.339 91.768 196.239 105.168 C 183.039 121.368 178.939 126.868 176.639 132.268 C 175.539 134.568 172.839 144.868 170.539 155.068 C 164.639 181.768 158.839 201.068 156.639 201.068 C 156.339 201.068 155.439 198.768 154.839 195.968 C 153.339 189.768 149.539 181.468 146.739 178.068 L 144.639 175.568 L 146.839 181.068 C 148.639 185.668 148.939 188.568 148.939 199.068 C 148.939 212.368 147.439 218.468 142.239 226.168 C 137.439 233.268 127.539 236.368 118.339 233.668 C 110.239 231.368 105.739 225.568 102.039 212.568 C 99.739 204.668 100.339 187.868 103.339 180.368 C 104.439 177.468 104.939 175.268 104.539 175.568 C 102.539 176.768 96.939 188.168 94.939 194.868 L 92.839 202.168 L 90.239 196.368 C 87.239 189.668 81.939 169.768 77.539 149.068 C 75.839 141.168 73.539 132.668 72.439 130.168 C 69.439 123.268 63.239 115.968 51.539 105.168 C 40.839 95.368 40.839 95.268 42.039 92.368 C 44.939 85.568 53.239 82.968 60.339 86.768 Z " fill="rgb(221,193,156)" vector-effect="non-scaling-stroke" stroke-width="1" stroke="rgb(63,39,10)" stroke-linejoin="miter" stroke-linecap="butt" stroke-miterlimit="4"/>
            <path d=" M 122.739 128.768 C 122.139 129.868 122.139 135.568 122.739 143.068 C 124.039 159.968 123.139 184.468 120.539 201.868 C 119.339 209.768 118.639 216.668 118.839 217.368 C 119.439 219.168 124.439 207.668 126.439 199.668 C 128.139 193.168 128.239 192.968 128.939 196.168 C 129.339 198.068 129.839 203.568 130.239 208.368 C 130.539 213.168 131.139 217.368 131.639 217.568 C 132.839 218.368 133.839 197.268 133.139 184.068 C 132.839 177.168 132.039 162.168 131.539 150.668 C 130.939 138.268 130.039 129.168 129.439 128.368 C 127.839 126.468 123.739 126.768 122.739 128.768 Z " fill="rgb(63,39,10)"/>
            <mask id="_mask_rVwlJvaGdOeGgrOJM4VE1Udmqdpr0C4B" x="-200%" y="-200%" width="400%" height="400%">
                <rect x="-200%" y="-200%" width="400%" height="400%" style="fill:white;"/>
                <path d=" M 195.039 31.568 C 193.139 33.368 192.539 35.068 192.539 38.468 C 192.539 42.168 193.039 43.268 195.639 45.468 C 197.639 47.168 199.939 48.068 202.139 48.068 C 210.439 48.068 214.939 37.368 209.039 31.568 C 204.939 27.368 204.039 28.168 204.239 36.268 L 204.539 43.568 L 202.739 37.568 C 199.939 28.068 199.139 27.368 195.039 31.568 Z  M 43.239 30.168 C 40.639 31.668 38.639 36.968 39.239 40.368 C 39.539 41.868 41.139 44.168 42.739 45.568 C 49.439 51.168 59.539 46.368 59.539 37.568 C 59.539 34.968 55.039 29.068 53.039 29.068 C 51.639 29.068 48.539 36.868 48.539 40.468 C 48.439 42.468 48.439 42.468 47.439 40.768 C 46.839 39.668 46.639 36.968 47.039 33.968 C 47.739 28.768 47.039 27.968 43.239 30.168 Z " fill-rule="evenodd" fill="black" stroke="none"/>
            </mask><path d=" M 195.039 31.568 C 193.139 33.368 192.539 35.068 192.539 38.468 C 192.539 42.168 193.039 43.268 195.639 45.468 C 197.639 47.168 199.939 48.068 202.139 48.068 C 210.439 48.068 214.939 37.368 209.039 31.568 C 204.939 27.368 204.039 28.168 204.239 36.268 L 204.539 43.568 L 202.739 37.568 C 199.939 28.068 199.139 27.368 195.039 31.568 Z  M 43.239 30.168 C 40.639 31.668 38.639 36.968 39.239 40.368 C 39.539 41.868 41.139 44.168 42.739 45.568 C 49.439 51.168 59.539 46.368 59.539 37.568 C 59.539 34.968 55.039 29.068 53.039 29.068 C 51.639 29.068 48.539 36.868 48.539 40.468 C 48.439 42.468 48.439 42.468 47.439 40.768 C 46.839 39.668 46.639 36.968 47.039 33.968 C 47.739 28.768 47.039 27.968 43.239 30.168 Z " fill-rule="evenodd" fill="#182C06" mask="url(#_mask_rVwlJvaGdOeGgrOJM4VE1Udmqdpr0C4B)" vector-effect="non-scaling-stroke" stroke-width="2" stroke="#182C06)" stroke-linejoin="miter" stroke-linecap="butt" stroke-miterlimit="4"/>
            <path id="ojos" d=" M 195.039 31.568 C 193.139 33.368 192.539 35.068 192.539 38.468 C 192.539 42.168 193.039 43.268 195.639 45.468 C 197.639 47.168 199.939 48.068 202.139 48.068 C 210.439 48.068 214.939 37.368 209.039 31.568 C 204.939 27.368 204.039 28.168 204.239 36.268 L 204.539 43.568 L 202.739 37.568 C 199.939 28.068 199.139 27.368 195.039 31.568 Z  M 43.239 30.168 C 40.639 31.668 38.639 36.968 39.239 40.368 C 39.539 41.868 41.139 44.168 42.739 45.568 C 49.439 51.168 59.539 46.368 59.539 37.568 C 59.539 34.968 55.039 29.068 53.039 29.068 C 51.639 29.068 48.539 36.868 48.539 40.468 C 48.439 42.468 48.439 42.468 47.439 40.768 C 46.839 39.668 46.639 36.968 47.039 33.968 C 47.739 28.768 47.039 27.968 43.239 30.168 Z " fill-rule="evenodd" fill="rgb(121,146,23)"/>
        </symbol>
</svg>

<svg class="llibreria" viewBox="0 0 250 250" width="250pt" height="250pt">
    <symbol id="fletxes" viewBox="0 0 250 250">
        <path d=" M 125 235.341 L 224.702 135.639 L 196.417 107.354 L 125 178.772 L 53.583 107.354 L 25.298 135.639 L 125 235.341 Z " fill="rgb(221,193,156)"/>
        <path d=" M 224.702 42.943 L 196.417 14.659 L 125 86.077 L 53.583 14.659 L 25.298 42.943 L 125 142.645 L 224.702 42.943 Z " fill="#DDC19C"/>
    </symbol>
</svg>

<svg class="llibreria" viewBox="0 0 250 250" width="250pt" height="250pt">
    <symbol id="serp2" viewBox="0 0 250 250">
        <path d=" M 44.539 5.668 C 38.639 7.768 34.839 10.568 33.039 14.068 L 31.539 16.968 L 36.339 17.568 C 43.139 18.468 49.639 20.768 52.639 23.368 C 54.039 24.568 57.239 28.268 59.739 31.568 C 64.839 38.268 69.539 42.768 77.339 48.868 L 82.639 52.968 L 78.839 53.768 C 72.039 55.168 56.439 54.568 50.439 52.768 C 37.639 48.868 31.139 39.868 31.039 25.868 L 31.039 18.068 L 27.139 18.068 C 17.539 18.068 9.439 23.368 5.439 32.268 C 3.339 36.868 3.039 39.068 3.039 49.068 C 3.139 71.968 7.739 78.768 48.239 117.068 C 54.339 122.868 60.139 129.168 61.039 131.068 C 62.039 132.968 64.539 142.468 66.539 152.068 C 73.639 185.268 78.839 201.568 84.939 209.468 C 86.239 211.168 89.339 216.768 91.939 221.868 C 94.439 226.968 98.239 232.868 100.139 235.068 C 104.539 239.868 114.139 244.668 121.239 245.568 C 127.139 246.368 136.339 244.768 141.539 242.068 C 147.139 239.168 153.739 231.368 158.939 221.068 C 161.639 215.868 164.939 210.168 166.239 208.468 C 171.439 201.568 176.239 186.268 183.039 154.568 C 188.539 129.068 189.039 128.168 207.939 111.068 C 231.239 90.068 239.639 80.068 244.639 67.168 C 246.539 62.468 246.939 59.468 246.939 48.568 C 247.039 35.768 246.939 35.468 243.939 30.068 C 239.939 22.968 234.039 19.068 225.839 18.368 C 220.539 17.868 219.939 17.568 218.539 14.668 C 215.439 8.168 203.739 3.468 193.139 4.368 C 189.039 4.668 185.039 5.868 181.039 7.968 C 169.539 13.968 134.539 18.068 112.339 16.168 C 90.839 14.268 76.939 11.568 70.039 7.968 C 62.539 4.068 51.739 3.068 44.539 5.668 Z  M 220.139 21.568 C 221.739 30.068 217.239 42.768 210.939 47.568 C 203.039 53.568 190.839 55.968 175.939 54.568 L 168.039 53.868 L 170.939 51.668 C 179.339 45.568 186.839 38.468 191.539 32.068 C 199.039 21.868 205.039 18.268 214.739 18.168 C 219.339 18.068 219.439 18.168 220.139 21.568 Z  M 108.239 63.368 C 103.039 66.768 103.039 66.568 108.239 69.868 C 114.339 73.768 117.539 77.068 115.339 77.068 C 113.239 77.068 96.539 66.868 97.139 65.968 C 97.739 64.968 106.239 62.168 108.539 62.168 C 109.639 62.168 109.639 62.468 108.239 63.368 Z  M 149.539 63.668 L 154.839 65.268 L 150.439 68.168 C 144.939 71.968 136.439 76.368 135.939 75.768 C 135.639 75.568 137.939 73.468 141.039 71.068 C 144.039 68.768 146.539 66.568 146.539 66.368 C 146.539 66.068 145.539 65.068 144.339 63.968 C 141.539 61.668 142.639 61.568 149.539 63.668 Z  M 60.339 86.768 C 62.039 87.768 66.839 91.368 70.839 94.768 L 78.239 100.968 L 77.739 113.268 C 77.439 122.368 77.739 127.368 78.939 132.468 C 80.839 140.468 87.039 152.868 92.039 158.568 L 95.539 162.568 L 92.939 156.668 C 87.139 143.068 86.239 130.668 90.339 117.568 C 91.839 112.468 92.439 111.568 94.239 111.868 C 95.739 112.068 98.639 110.068 103.639 105.568 C 112.739 97.468 117.739 94.968 124.939 94.968 C 132.239 94.968 137.439 97.768 144.939 105.668 C 149.539 110.568 151.639 112.068 153.739 112.068 C 156.139 112.068 156.639 112.668 158.039 117.268 C 162.039 130.368 160.839 146.368 154.939 158.468 L 152.439 163.568 L 156.539 159.068 C 161.139 154.068 167.739 141.068 169.439 133.768 C 171.239 126.068 171.839 114.068 170.639 108.068 L 169.639 102.568 L 175.039 97.368 C 187.239 85.768 195.939 82.368 201.839 87.068 C 207.439 91.468 207.339 91.768 196.239 105.168 C 183.039 121.368 178.939 126.868 176.639 132.268 C 175.539 134.568 172.839 144.868 170.539 155.068 C 164.639 181.768 158.839 201.068 156.639 201.068 C 156.339 201.068 155.439 198.768 154.839 195.968 C 153.339 189.768 149.539 181.468 146.739 178.068 L 144.639 175.568 L 146.839 181.068 C 148.639 185.668 148.939 188.568 148.939 199.068 C 148.939 212.368 147.439 218.468 142.239 226.168 C 137.439 233.268 127.539 236.368 118.339 233.668 C 110.239 231.368 105.739 225.568 102.039 212.568 C 99.739 204.668 100.339 187.868 103.339 180.368 C 104.439 177.468 104.939 175.268 104.539 175.568 C 102.539 176.768 96.939 188.168 94.939 194.868 L 92.839 202.168 L 90.239 196.368 C 87.239 189.668 81.939 169.768 77.539 149.068 C 75.839 141.168 73.539 132.668 72.439 130.168 C 69.439 123.268 63.239 115.968 51.539 105.168 C 40.839 95.368 40.839 95.268 42.039 92.368 C 44.939 85.568 53.239 82.968 60.339 86.768 Z " fill="rgb(63,39,10)" vector-effect="non-scaling-stroke" stroke-width="1" stroke="#000" stroke-linejoin="miter" stroke-linecap="butt" stroke-miterlimit="4"/>
        <path d=" M 122.739 128.768 C 122.139 129.868 122.139 135.568 122.739 143.068 C 124.039 159.968 123.139 184.468 120.539 201.868 C 119.339 209.768 118.639 216.668 118.839 217.368 C 119.439 219.168 124.439 207.668 126.439 199.668 C 128.139 193.168 128.239 192.968 128.939 196.168 C 129.339 198.068 129.839 203.568 130.239 208.368 C 130.539 213.168 131.139 217.368 131.639 217.568 C 132.839 218.368 133.839 197.268 133.139 184.068 C 132.839 177.168 132.039 162.168 131.539 150.668 C 130.939 138.268 130.039 129.168 129.439 128.368 C 127.839 126.468 123.739 126.768 122.739 128.768 Z " fill="rgb(229, 60, 67)"/>
        <mask id="_mask_rVwlJvaGdOeGgrOJM4VE1Udmqdpr0C4B" x="-200%" y="-200%" width="400%" height="400%">
            <rect x="-200%" y="-200%" width="400%" height="400%" style="fill:white;"/>
            <path d=" M 195.039 31.568 C 193.139 33.368 192.539 35.068 192.539 38.468 C 192.539 42.168 193.039 43.268 195.639 45.468 C 197.639 47.168 199.939 48.068 202.139 48.068 C 210.439 48.068 214.939 37.368 209.039 31.568 C 204.939 27.368 204.039 28.168 204.239 36.268 L 204.539 43.568 L 202.739 37.568 C 199.939 28.068 199.139 27.368 195.039 31.568 Z  M 43.239 30.168 C 40.639 31.668 38.639 36.968 39.239 40.368 C 39.539 41.868 41.139 44.168 42.739 45.568 C 49.439 51.168 59.539 46.368 59.539 37.568 C 59.539 34.968 55.039 29.068 53.039 29.068 C 51.639 29.068 48.539 36.868 48.539 40.468 C 48.439 42.468 48.439 42.468 47.439 40.768 C 46.839 39.668 46.639 36.968 47.039 33.968 C 47.739 28.768 47.039 27.968 43.239 30.168 Z " fill-rule="evenodd" fill="black" stroke="none"/>
        </mask><path d=" M 195.039 31.568 C 193.139 33.368 192.539 35.068 192.539 38.468 C 192.539 42.168 193.039 43.268 195.639 45.468 C 197.639 47.168 199.939 48.068 202.139 48.068 C 210.439 48.068 214.939 37.368 209.039 31.568 C 204.939 27.368 204.039 28.168 204.239 36.268 L 204.539 43.568 L 202.739 37.568 C 199.939 28.068 199.139 27.368 195.039 31.568 Z  M 43.239 30.168 C 40.639 31.668 38.639 36.968 39.239 40.368 C 39.539 41.868 41.139 44.168 42.739 45.568 C 49.439 51.168 59.539 46.368 59.539 37.568 C 59.539 34.968 55.039 29.068 53.039 29.068 C 51.639 29.068 48.539 36.868 48.539 40.468 C 48.439 42.468 48.439 42.468 47.439 40.768 C 46.839 39.668 46.639 36.968 47.039 33.968 C 47.739 28.768 47.039 27.968 43.239 30.168 Z " fill-rule="evenodd" fill="#182C06" mask="url(#_mask_rVwlJvaGdOeGgrOJM4VE1Udmqdpr0C4B)" vector-effect="non-scaling-stroke" stroke-width="2" stroke="#182C06)" stroke-linejoin="miter" stroke-linecap="butt" stroke-miterlimit="4"/>
        <path id="ojos" d=" M 195.039 31.568 C 193.139 33.368 192.539 35.068 192.539 38.468 C 192.539 42.168 193.039 43.268 195.639 45.468 C 197.639 47.168 199.939 48.068 202.139 48.068 C 210.439 48.068 214.939 37.368 209.039 31.568 C 204.939 27.368 204.039 28.168 204.239 36.268 L 204.539 43.568 L 202.739 37.568 C 199.939 28.068 199.139 27.368 195.039 31.568 Z  M 43.239 30.168 C 40.639 31.668 38.639 36.968 39.239 40.368 C 39.539 41.868 41.139 44.168 42.739 45.568 C 49.439 51.168 59.539 46.368 59.539 37.568 C 59.539 34.968 55.039 29.068 53.039 29.068 C 51.639 29.068 48.539 36.868 48.539 40.468 C 48.439 42.468 48.439 42.468 47.439 40.768 C 46.839 39.668 46.639 36.968 47.039 33.968 C 47.739 28.768 47.039 27.968 43.239 30.168 Z " fill-rule="evenodd" fill="rgb(229, 60, 67)"/>
    </symbol>
</svg>

</html>