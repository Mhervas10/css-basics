<footer>
       <div class="divfooter">
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum, vitae repellendus.</p>
        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit.</p>
        </div> 
    </footer>